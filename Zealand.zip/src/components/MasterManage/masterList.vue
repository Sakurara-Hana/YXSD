<template>
    <div>
        主号列表
    </div>
</template>
<script>
  export default {
    data() {
      return {
      };
    }
  };
</script>

<style lang scoped>
    
</style>