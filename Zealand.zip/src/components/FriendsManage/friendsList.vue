<template>
    <div>
        朋友列表
    </div>
</template>
<script>
  export default {
    data() {
      return {
      };
    }
  };
</script>

<style lang scoped>
    
</style>