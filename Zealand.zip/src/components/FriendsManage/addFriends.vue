<template>
    <div>
        添加朋友
    </div>
</template>
<script>
  export default {
    data() {
      return {
      };
    }
  };
</script>

<style lang scoped>
    
</style>