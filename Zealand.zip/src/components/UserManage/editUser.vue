<template>
    <div>
        编辑用户
    </div>
</template>
<script>
  export default {
    data() {
      return {
      };
    }
  };
</script>

<style lang scoped>
    
</style>