<template>
    <div>
    {{info}}
    </div>
</template>
<script>
export default {
   data(){
       return {
           info:'学生信息',
       }
   } 
}
</script>

<style lang scoped>
    
</style>