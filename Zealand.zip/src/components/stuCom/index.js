
// import studentCourse1 from './studentCourse.vue'
// import studentInfo1 from './studentInfo.vue'

// export var studentCourse=studentCourse1
// export var studentInfo=studentInfo1

// export var studentCourse=()=>import('./studentCourse.vue')
// export var studentInfo=()=>import('./studentInfo.vue')
// export var studentInfo=()=>{
//     return     import('./studentInfo.vue')
// }
    
    
