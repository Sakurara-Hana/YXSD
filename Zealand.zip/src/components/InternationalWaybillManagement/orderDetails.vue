<template>
  <div class="details">
    <!-- 头部区域 -->
    <div class="header_wrap">
      <div class="header_top">
        <div class="top_btn">
          <el-button type="primary" icon="el-icon-arrow-left">返回</el-button>
          <div class="a1">
            <ul>
              <li>问题包裹</li>
              <li>编辑发票</li>
              <li>修改后台状态</li>
              <li>修改前台状态</li>
              <li>内部备注</li>
              <li>包裹属性</li>
              <li>取消</li>
            </ul>
          </div>
          <div class="a2">
            <ul>
              <li>打印清单</li>
              <li>地址标签</li>
              <li>打印发票</li>
              <li>快递单</li>
            </ul>
          </div>
          <div class="a3">
            <ul>
              <li>打印清单-t</li>
              <li>地址标签-t</li>
              <li>快递单-t</li>
              <li>一键打印全部</li>
            </ul>
          </div>
        </div>
        <div class="top_details">
          <span>运单编号:190917172R74B</span>
          <span>|</span>
          <span>用户:amz519</span>
          <span>|</span>
          <span>仓库号:P0GUJ</span>
          <span>|</span>
          <span>提交时间:2019-09-17 12:16:52</span>
          <span>|</span>
          <span>付款时间:2019-09-17 12:16:52</span>
        </div>
      </div>
      <div class="header_bottom">
        <el-progress :percentage="percentage" :color="customColor"></el-progress>
        <div>
          <el-button-group>
            <el-button icon="el-icon-minus" @click="decrease"></el-button>
            <el-button icon="el-icon-plus" @click="increase"></el-button>
          </el-button-group>
        </div>
      </div>
    </div>
    <!-- 状态区域  -->
    <div class="status_wrap"></div>
    <!-- 出库流程区域 -->
    <div class="process"></div>
    <!-- 清单区域 -->
    <div class="detailedList"></div>
  </div>
</template>


<script>
export default {
data(){
    return {
        percentage: 0
    }
},
 methods:{
increase() {
        this.percentage += 10;
        if (this.percentage > 100) {
          this.percentage = 100;
        }
      },
      decrease() {
        this.percentage -= 10;
        if (this.percentage < 0) {
          this.percentage = 0;
        }
      }
}
}
</script>

<style scoped>
div.details {
  height: 100%;
  width: 100%;
  /* background-color: #fafafa; */
  margin: 0;
  padding: 0;
}
/* 头部区域 */
div.details div.header_wrap {
  width: 100%;
  height: 20%;
  background-color: red;
}
/* 头部区域的按钮部分,运单信息部分 */
div.details div.header_wrap div.header_top {
  height: 50%;
  width: 100%;
  background-color: #fafafa;
}

div.details div.header_wrap div.header_top div.top_btn {
  height: 50%;
  display: flex;
  /* background-color: seagreen; */
}
div.details div.header_wrap div.header_top div.top_btn button.el-button {
  height: 30px;
  padding: 7px 7px;
}
div.details div.header_wrap div.header_top div.top_btn ul {
  font-size: 15px;
  display: flex;
  margin: 0 10px;
  margin-top: 5px;
}
div.details div.header_wrap div.header_top div.top_btn ul li {
  /* background-color: red; */
  margin: 0 0.5px;
  padding: 1px 4px;
  border: 1px solid #989898;
  background-color: #eaeaea;
  border-radius: 3px;
  cursor: pointer;
}
div.details div.header_wrap div.header_top div.top_details {
  height: 50%;
  display: flex;
}
div.details div.header_wrap div.header_top div.top_details span {
  margin-top: 7px;
  margin-left: 10px;
  font-size: 14px;
  color: #989898;
}
/* 头部的进度条部分 */
div.details div.header_wrap div.header_bottom {
  height: 50%;
  width: 100%;
  background-color: rgb(79, 107, 150);
}
div.details div.header_wrap div.header_bottom div.el-progress{
    height: 40%;
}
div.details div.header_wrap div.header_bottom div.el-progress div.el-progress-bar__outer{
    height: 13px;
}
/* 状态区域 */
div.details div.status_wrap {
  width: 100%;
  height: 30%;
  background-color: rgb(62, 209, 26);
}
/* 出库流程区域 */
div.details div.process {
  width: 100%;
  height: 30%;
  background-color: rgb(160, 209, 26);
}
/* 物品清单区域 */
div.details div.detailedList {
  width: 100%;
  height: 20%;
  background-color: rgb(209, 26, 179);
}
</style>