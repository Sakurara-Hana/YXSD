<template>
  <div class="app-container">
    <div class="filter-container">
      <!-- 查找--search区域 -->
      <div class="search_wrap">
        <el-input
          v-model="listQuery.title"
          placeholder="输入单号/仓库号/用户名等"
          style="width: 200px;"
          class="filter-item"
          @keyup.enter.native="handleFilter"
        />
        <div class="date_wrap">
          <el-date-picker
            v-model="formSearch.start_time"
            type="datetime"
            placeholder="选择开始日期"
            :picker-options="start_Date"
          />
          <span>--</span>
          <el-date-picker
            v-model="formSearch.end_time"
            type="datetime"
            placeholder="选择结束日期"
            :picker-options="end_Date"
          />
        </div>
        <!-- 筛选按钮区域 -->
        <el-button
          class="filter-item"
          type="primary"
          icon="el-icon-search"
          @click="handleFilter"
        >Search</el-button>
      </div>
      <!-- 下载按钮区域 -->
      <div class="down_wrap">
        <el-button
          :loading="downloadLoading"
          class="filter-item"
          type="primary"
          icon="el-icon-download"
          @click="handleDownload"
        >Export</el-button>
      </div>
    </div>

    <!-- 表格区域 -->
    <el-table
      id="excel-table"
      v-loading="loading"
      ref="filterTable"
      :data="tableData"
      style="width: 100%"
      :expand-row-keys="expends"
      :row-key="getRowKeys"
    >
      <!-- 多选框 -->
    <el-table-column type="expand" width="100">
          <template  slot-scope="props">
            <!-- 评价：{{ props.row.comment}} -->
            <span class="sub"> 提交：2019-09-17  12:16:52</span>
            <span>付款：2019-09-17  12:16:52</span>
            <span>仓库号:PGUJ</span>
            <span>用户名:amz519</span>
          
            </template>
        </el-table-column>
      <el-table-column type="selection" width="45"></el-table-column>
      <el-table-column prop="yun" label="悠奇运单编号" width="120"></el-table-column>
      <el-table-column
        prop="fangshi"
        label="运送方式"
        width="100"
        :filters="[{ text: 'DHL', value: 'DHL' }, { text: 'EMS', value: 'EMS' },
                    { text: '西马海运包税快递', value: '西马海运包税快递' },
                    { text: '中国邮政大包', value: '中国邮政大包' },
                    { text: 'E邮宝', value: 'E邮宝' },
                    { text: '西马包税专线(建议大货)', value: '西马包税专线(建议大货)' }
                    ]"
        :filter-method="filterTag"
        filter-placement="bottom-end"
      >
        <template slot-scope="scope">
          <el-tag
            :type="scope.row.fangshi === 'DHL' ? 'primary' : 'success'"
            disable-transitions
          >{{scope.row.fangshi}}</el-tag>
        </template>
      </el-table-column>
      <el-table-column
        prop="destination"
        label="目的地"
        width="90"
        :filters="[{ text: '美国', value: '美国' }, { text: '马来西亚', value: '马来西亚' }]"
        :filter-method="filterTag"
        filter-placement="bottom-end"
      >
        <template slot-scope="scope">
          <el-tag
            :type="scope.row.destination === '美国' ? 'primary' : 'success'"
            disable-transitions
          >{{scope.row.destination}}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="addressee" label="收件人" width="90"></el-table-column>
      <el-table-column prop="netWeight" sortable label="物品净重(kg)" width="120"></el-table-column>
      <el-table-column prop="weight" sortable label="预付重量(kg)" width="115"></el-table-column>
      <el-table-column prop="advanceCharge" sortable label="预付款(rmb)" width="115"></el-table-column>
      <el-table-column
        prop="channel"
        label="发货渠道"
        width="100"
        :filters="[
                  { text: '递四方', value: '递四方' }, 
                  { text: '互联易', value: '互联易' }, 
                  { text: '商壹运通', value: '商壹运通' },
                  { text: '跨境翼欧线', value: '跨境翼欧线' }
                  ]"
        :filter-method="filterTag"
        filter-placement="bottom-end"
      >
        <template slot-scope="scope">
          <el-tag
            :type="scope.row.channel === '递四方' ? 'primary' : 'success'"
            disable-transitions
          >{{scope.row.channel}}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="channelNumber" label="渠道单号" width="90"></el-table-column>
      <el-table-column prop="conversionNumber" label="转单号" width="80"></el-table-column>
      <el-table-column prop="status" label="状态" width="100"></el-table-column>
      <el-table-column label="操作">
        <!-- <template slot-scope="scope"> -->
        <el-button @click="dialogFormVisible = true" size="mini" type="primary">详情</el-button>
        <!-- <el-button @click="del(scope.row.id)" size="mini" type="danger">Delete</el-button> -->
        <!-- </template> -->
      </el-table-column>
    </el-table>
    <!-- 分页区域 -->
    <el-pagination
      background
      layout="prev, pager, next"
      @current-change="getShowCount"
      :page-size="pageSize"
      :total="totalCount"
    ></el-pagination>
    <!-- 弹出框--编辑区域 -->
    <el-dialog title="编辑用户" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item label="Date" :label-width="formLabelWidth">
          <el-date-picker v-model="form.date" type="datetime" placeholder="Please pick a date" />
        </el-form-item>
        <el-form-item label="姓名" :label-width="formLabelWidth">
          <el-input v-model="form.name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="地址" :label-width="formLabelWidth">
          <el-input v-model="form.address" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item class="select_wrap" label="标签" :label-width="formLabelWidth">
          <el-select v-model="form.tag" placeholder="请选择tag">
            <el-option label="家" value="家"></el-option>
            <el-option label="公司" value="公司"></el-option>
          </el-select>
        </el-form-item>
       
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { parseTime } from "@/utils"; //格式化时间
import FileSaver from "file-saver";
import XLSX from "xlsx";
import _ from "../utils/format";
const calendarTypeOptions = [
  { key: "CN", display_name: "China" },
  { key: "US", display_name: "USA" },
  { key: "JP", display_name: "Japan" },
  { key: "EU", display_name: "Eurozone" }
];

// arr to obj, such as { CN : "China", US : "USA" }
const calendarTypeKeyValue = calendarTypeOptions.reduce((acc, cur) => {
  acc[cur.key] = cur.display_name;
  return acc;
}, {});

export default {
  name: "ComplexTable",
  // components: { Pagination },
  // directives: { waves },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: "success",
        draft: "info",
        deleted: "danger"
      };
      return statusMap[status];
    },
    typeFilter(type) {
      return calendarTypeKeyValue[type];
    }
  },
  data() {
    return {
      expends:[],
      // 时间选择器，控制开始时间和结束时间
      formSearch: {
        //搜索
        start_time: null,
        end_time: null
      },
      start_Date: {
        //时间限制
        disabledDate: time => {
          return time > Date.now();
        }
      },
      end_Date: {
        //时间限制
        disabledDate: time => {
          return time.getTime() < this.formSearch.start_time;
        }
      },
      totalCount: 3, //分页的总页码
      pageSize: 2, //一页有多少条
      dialogTableVisible: false,
      dialogFormVisible: false,
      form: {
        name: "",
        region: "",
        date1: "",
        date2: "",
        delivery: false,
        type: [],
        resource: "",
        desc: ""
      },
      formLabelWidth: "120px",
      loading: false,
      tableData: [
        {
          yun: "190917172R74B",
          fangshi: "DHL",
          destination: "美国",
          addressee: "Amy Zhu",
          netWeight: "5.61",
          weight: "10.01",
          advanceCharge: "684.25",
          channel: "递四方",
          channelNumber: "6186164412",
          conversionNumber: "暂无",
          status: "待打包",
          comment:'我和我的祖国',
          id: 1,
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄",
          tag: "家"
        },
        {
          yun: "190917172R74B",
          fangshi: "DHL",
          destination: "马来西亚",
          addressee: "Annie Cui",
          netWeight: "7.67",
          weight: "16.32",
          advanceCharge: "1015.45",
          channel: "互联易",
          channelNumber: "6186164154",
          conversionNumber: "暂无",
          status: "待打包",
          comment:'我和我的祖国',
          id: 2,
          date: "2016-05-04",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1517 弄",
          tag: "公司"
        },
        {
          yun: "190917172R74B",
          fangshi: "DHL",
          destination: "加拿大",
          addressee: "Yap chwee lan",
          netWeight: "5.3",
          weight: "10.01",
          advanceCharge: "140.00",
          channel: "递四方",
          channelNumber: "8412439814",
          conversionNumber: "8412439814",
          status: "待交运",
          comment:'我和我的祖国',
          id: 3,
          date: "2016-05-01",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1519 弄",
          tag: "家"
        },
        {
          yun: "190917172R74B",
          fangshi: "DHL",
          destination: "澳大利亚",
          addressee: "Jeff Hong",
          netWeight: "1.75",
          weight: "15.531",
          advanceCharge: "118.00",
          channel: "商壹运通",
          channelNumber: "8412439840",
          conversionNumber: "暂无",
          status: "待打包",
          comment:'我和我的祖国',
          id: 4,
          date: "2016-05-03",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1516 弄",
          tag: "公司"
        },
        {
          yun: "190917172R74B",
          fangshi: "DHL",
          destination: "美国",
          addressee: "Yucen Liu",
          netWeight: "9.18",
          weight: "2.376",
          advanceCharge: "455.00",
          channel: "跨境翼欧线",
          channelNumber: "暂无",
          conversionNumber: "暂无",
          status: "待确认渠道",
          comment:'我和我的祖国',
          id: 5,
          date: "2016-04-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1516 弄",
          tag: "公司"
        },
        {
          yun: "190917172R74B",
          fangshi: "DHL",
          destination: "美国",
          addressee: "Amy Zhu",
          netWeight: "5.61",
          weight: "10.01",
          advanceCharge: "684.25",
          channel: "递四方",
          channelNumber: "6186164412",
          conversionNumber: "暂无",
          status: "待打包",
          comment:'我和我的祖国',
          id: 6,
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄",
          tag: "家"
        },
        {
          yun: "190917172R74B",
          fangshi: "DHL",
          destination: "马来西亚",
          addressee: "Annie Cui",
          netWeight: "7.67",
          weight: "16.32",
          advanceCharge: "1015.45",
          channel: "互联易",
          channelNumber: "6186164154",
          conversionNumber: "暂无",
          status: "待打包",
          comment:'我和我的祖国',
          id: 7,
          date: "2016-05-04",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1517 弄",
          tag: "公司"
        },
        {
          yun: "190917172R74B",
          fangshi: "DHL",
          destination: "加拿大",
          addressee: "Yap chwee lan",
          netWeight: "5.3",
          weight: "10.01",
          advanceCharge: "140.00",
          channel: "递四方",
          channelNumber: "8412439814",
          conversionNumber: "8412439814",
          status: "待交运",
          comment:'我和我的祖国',
          id: 8,
          date: "2016-05-01",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1519 弄",
          tag: "家"
        },
        {
          yun: "190917172R74B",
          fangshi: "DHL",
          destination: "澳大利亚",
          addressee: "Jeff Hong",
          netWeight: "1.75",
          weight: "15.531",
          advanceCharge: "118.00",
          channel: "商壹运通",
          channelNumber: "8412439840",
          conversionNumber: "暂无",
          status: "待打包",
          comment:'我和我的祖国',
          id: 9,
          date: "2016-05-03",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1516 弄",
          tag: "公司"
        },
        {
          yun: "190917172R74B",
          fangshi: "DHL",
          destination: "美国",
          addressee: "Yucen Liu",
          netWeight: "9.18",
          weight: "2.376",
          advanceCharge: "455.00",
          channel: "跨境翼欧线",
          channelNumber: "暂无",
          conversionNumber: "暂无",
          status: "待确认渠道",
          comment:'我和我的祖国',
          id: 10,
          date: "2016-04-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1516 弄",
          tag: "公司"
        }
      ],

      tableKey: 0,
      list: null,
      total: 0,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 20,
        importance: undefined,
        title: undefined,
        type: undefined,
        sort: "+id"
      },
      importanceOptions: [1, 2, 3],
      calendarTypeOptions,
      sortOptions: [
        { label: "ID Ascending", key: "+id" },
        { label: "ID Descending", key: "-id" }
      ],
      statusOptions: ["published", "draft", "deleted"],
      showReviewer: false,
      temp: {
        id: undefined,
        importance: 1,
        remark: "",
        timestamp: new Date(),
        title: "",
        type: "",
        status: "published"
      },
      dialogFormVisible: false,
      dialogStatus: "",
      textMap: {
        update: "Edit",
        create: "Create"
      },
      dialogPvVisible: false,
      pvData: [],
      rules: {
        type: [
          { required: true, message: "type is required", trigger: "change" }
        ],
        timestamp: [
          {
            type: "date",
            required: true,
            message: "timestamp is required",
            trigger: "change"
          }
        ],
        title: [
          { required: true, message: "title is required", trigger: "blur" }
        ]
      },
      downloadLoading: false
    };
  },
  created() {
    this.getExpends();
  },
  methods: {
    //设置table中的扩展项，展开的id，此处我需要全部展开
    getExpends(){
      var tranId = this.tableData.map(item => item.id)
            this.expends = tranId
    },
    getRowKeys(row){
      return row.id
    },
    //分页部分
    getShowCount() {
      this.totalCount = 3;
    },
    getShowList() {
      var _this = this;
      this.$axios
        .get("http://www.liulongbin.top:3005/api/getnewslist")
        .then(function(response) {
          console.log("get");
          if (response.status == 0) {
            _this.tableData = response.message;
          }
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    del(id) {
      console.log(id);
      this.$confirm("此操作将永久删除该文件, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.tableData.map((n, index) => {
            if (n.id == id) {
              this.tableData.splice(index, 1);
            }
          });
          this.$message({
            type: "success",
            message: "删除成功!"
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    fmtTime(row, column, cellValue, index) {
      var time = _.convertMysqlTime2JSTime(cellValue);
      return time.getFormatDate() + "   " + time.getFormatTime();
    },
    formatter(row, column) {
      return row.address;
    },
    filterTag(value, row) {
      return row.tag === value;
    },
    filterHandler(value, row, column) {
      const property = column["property"];
      return row[property] === value;
    },

    getList() {
      // this.listLoading = true;
      // fetchList(this.listQuery).then(response => {
      //   this.list = response.data.items
      //   this.total = response.data.total
      //   // Just to simulate the time of the request
      //   setTimeout(() => {
      //     this.listLoading = false
      //   }, 1.5 * 1000)
      // })
    },
    handleFilter() {
      this.listQuery.page = 1;
      this.getList();
    },
    handleModifyStatus(row, status) {
      this.$message({
        message: "操作Success",
        type: "success"
      });
      row.status = status;
    },
    sortChange(data) {
      const { prop, order } = data;
      if (prop === "id") {
        this.sortByID(order);
      }
    },
    sortByID(order) {
      if (order === "ascending") {
        this.listQuery.sort = "+id";
      } else {
        this.listQuery.sort = "-id";
      }
      this.handleFilter();
    },
    resetTemp() {
      this.temp = {
        id: undefined,
        importance: 1,
        remark: "",
        timestamp: new Date(),
        title: "",
        status: "published",
        type: ""
      };
    },
    handleCreate() {
      this.resetTemp();
      this.dialogStatus = "create";
      this.dialogFormVisible = true;
      this.$nextTick(() => {
        this.$refs["dataForm"].clearValidate();
      });
    },
    createData() {
      this.$refs["dataForm"].validate(valid => {
        if (valid) {
          this.temp.id = parseInt(Math.random() * 100) + 1024; // mock a id
          this.temp.author = "vue-element-admin";
          // createArticle(this.temp).then(() => {
          //   this.list.unshift(this.temp)
          //   this.dialogFormVisible = false
          //   this.$notify({
          //     title: 'Success',
          //     message: 'Created Successfully',
          //     type: 'success',
          //     duration: 2000
          //   })
          // })
        }
      });
    },
    handleUpdate(row) {
      this.temp = Object.assign({}, row); // copy obj
      this.temp.timestamp = new Date(this.temp.timestamp);
      this.dialogStatus = "update";
      this.dialogFormVisible = true;
      this.$nextTick(() => {
        this.$refs["dataForm"].clearValidate();
      });
    },
    updateData() {
      this.$refs["dataForm"].validate(valid => {
        if (valid) {
          const tempData = Object.assign({}, this.temp);
          tempData.timestamp = +new Date(tempData.timestamp); // change Thu Nov 30 2017 16:41:05 GMT+0800 (CST) to 1512031311464
          // updateArticle(tempData).then(() => {
          //   for (const v of this.list) {
          //     if (v.id === this.temp.id) {
          //       const index = this.list.indexOf(v)
          //       this.list.splice(index, 1, this.temp)
          //       break
          //     }
          //   }
          //   this.dialogFormVisible = false
          //   this.$notify({
          //     title: 'Success',
          //     message: 'Update Successfully',
          //     type: 'success',
          //     duration: 2000
          //   })
          // })
        }
      });
    },
    handleDelete(row) {
      this.$notify({
        title: "Success",
        message: "Delete Successfully",
        type: "success",
        duration: 2000
      });
      const index = this.list.indexOf(row);
      this.list.splice(index, 1);
    },
    //  handleFetchPv(pv) {
    //    fetchPv(pv).then(response => {
    //     this.pvData = response.data.pvData
    //      this.dialogPvVisible = true
    //    })
    // },
    handleDownload() {
      // this.downloadLoading = true;
      import("@/vendor/Export2Excel").then(excel => {
        const tHeader = ["id", "时间", "姓名", "地址", "标签"];
        const filterVal = ["id", "date", "name", "address", "tag"];
        const data = this.formatJson(filterVal, this.tableData);
        console.log(data);
        // const data = this.tableData;
        excel.export_json_to_excel({
          header: tHeader,
          data,
          filename: "table-list"
        });
        // this.downloadLoading = false;
      });
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v =>
        filterVal.map(j => {
          if (j === "id") {
            //这里其实是格式化的一个判断，如没有要格式化的字段可以不用次判断
            // return parseTime(v[j])
            return v[j];
          } else {
            return v[j];
          }
        })
      );
    },
    getSortClass: function(key) {
      const sort = this.listQuery.sort;
      return sort === `+${key}`
        ? "ascending"
        : sort === `-${key}`
        ? "descending"
        : "";
    }
  }
};
</script>
<style scope>
/* 查询区域 */

div.filter-container {
  height: 30px;
  display: flex;
  justify-content: space-between;
  /* justify-content: space-around; */
  border-bottom: 1px solid #eaeaea;
  background-color: #fafafa;
}
div.filter-container .filter-item {
  /* margin-left: 10px; */
  margin: 0 10px;
}
div.filter-container .search_wrap {
  display: flex;
}
/* 输入框的样式 */
div.filter-container .filter-item .el-input__inner {
  height: 23px;
}
/* 选择器中的下拉小图标样式 */
div.filter-container
  .filter-item
  .el-input
  .el-input__suffix
  .el-input__suffix-inner
  .el-input__icon {
  line-height: 23px;
}

/* 时间选择器 */
div.filter-container div.search_wrap .el-date-editor .el-input__inner {
  height: 23px;
}

div.filter-container
  div.search_wrap
  .el-date-editor
  .el-input__prefix
  .el-input__icon {
  line-height: 23px;
}
div.filter-container
  div.search_wrap
  .el-date-editor
  .el-input__suffix
  .el-input__icon {
  line-height: 23px;
}

/* 查询按钮 */
button.el-button.filter-item.el-button--primary {
  height: 23px;
}
/* 查询按钮的内容居中 */
div.filter-container div.search_wrap button.el-button {
  font-size: 11px;
  padding: 4px 10px;
}
/* 下载按钮的内容居中 */
div.filter-container div.down_wrap button.el-button {
  font-size: 11px;
  padding: 4px 10px;
}

/* 表格区域 */
div.el-table__body-wrapper.is-scrolling-left{
  overflow-x: hidden;
}
/* 表头部分 */
.el-table th {
  padding: 1px 0;
  background-color: #e7edf6;
  color: #000000;
  font-size: 10px;
}
/* 表格行td部分 */
.el-table td {
  padding: 1px 0;
  font-size: 7px;
  color: #000000;
  background-color: #FEFEFE;
}
/* 扩展行部分 */
.el-table td.el-table__expanded-cell{
  padding: 5px 50px;
  color: #656565;
  background-color: #F4F4F4;
}
/* 扩展行 span部分 */
.el-table td.el-table__expanded-cell span.sub{
  margin-left: 40px;
}
.el-table td.el-table__expanded-cell span{
  margin-left: 30px;
}
/* 表格中标签按钮部分 */
.el-table td div.cell span.el-tag{
height: 25px;
line-height: 25px;
padding: 0 5px;
}


/* 表格中 详情按钮 */
button.el-button--mini {
  /* margin-left: 5px; */
  padding:  5px 12px;
}
div.el-pagination {
  padding: 35px 5px;
}

/* 弹出层区域 */
div.el-dialog {
  /* width: 40%; */
}
div.el-form-item__content {
  /* margin-left: 60px !important; */
}

div.el-date-picker {
  /* width: 100%; */
}
div.el-input {
  /* width: 70%; */
}
div.el-select {
  /* margin-left: 60px ; */

  /* width: 80%; */
}
</style>
