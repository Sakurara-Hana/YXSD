<template>
    <div>
        编辑任务
    </div>
</template>
<script>
  export default {
    data() {
      return {
      };
    }
  };
</script>

<style lang scoped>
    
</style>